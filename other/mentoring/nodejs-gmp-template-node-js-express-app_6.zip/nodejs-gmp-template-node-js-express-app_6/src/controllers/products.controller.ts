import { NextFunction, Response, Request } from "express";
import {
  findProducts,
  findProduct,
  updateProduct,
  createProduct,
  removeProduct
} from "../services/products.service";

export const getProducts = (req: Request, res:Response, _: NextFunction) => {
  const products = findProducts();
  res.status(200).json({
    data: products
  })
}

export const getProduct = (req: Request, res:Response, _: NextFunction) => {
  const { id } = req.params;

  const product = findProduct(id);

  if (!product) {
    return res.status(404).json({
      error: 'Product not found'
    })
  }

  return res.status(200).json({
    data: product
  })
}

export const createNewProduct = (req: Request, res:Response, _: NextFunction) => {
  const {body: data} = req;

  const newProduct = createProduct(data);
  return res.status(201).json({
    data: newProduct
  });
}

export const replaceProduct = (req: Request, res:Response, _: NextFunction) => {
  const {body: data} = req;
  const {id} = req.params;

  const updatedProduct = updateProduct(id, data);
  if (!updatedProduct) {
    return res.status(404).json({
      error: 'Product not found'
    })
  }
  return res.status(200).json({
    data: updatedProduct
  });
}

export const deleteProduct = (req: Request, res:Response, _: NextFunction) => {
  const { id } = req.params;

  const removed = removeProduct(id);

  if (!removed) {
    return res.status(404).json({
      error: 'Product not found'
    })
  }
  return res.status(200).json({ message: 'Product deleted successfully' });
}