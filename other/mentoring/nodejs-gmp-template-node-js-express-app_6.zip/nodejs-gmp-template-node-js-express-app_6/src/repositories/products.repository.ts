import { products } from "../data/products";
import { ProductEntity } from "../entities/product.entity";
import { randomUUID } from 'crypto';

const PRODUCTS: ProductEntity[] = [...products];

export const find = (): ProductEntity[] => [...PRODUCTS];

export const findOne = (id: string): ProductEntity | null => PRODUCTS.find(el => el.id === id) || null;

export const create = (data: Omit<ProductEntity, 'id'>): ProductEntity => {
  const id = randomUUID();
  const product = {
    id,
    ...data
  };
  PRODUCTS.push(product);
  return product;
}

export const update = (data: ProductEntity): ProductEntity | null  => {

  const productIndex = PRODUCTS.findIndex((el) => el.id === data.id);

  if (productIndex === -1) {
    return null;
  }

  PRODUCTS[productIndex] = data;

  return data;
};

export const remove = (id: string): string | null => {
  const productIndex = PRODUCTS.findIndex((el) => el.id === id);

  if (productIndex === -1) {
    return null;
  }

  PRODUCTS.splice(productIndex, 1);

  return id;
}