import { ProductEntity } from "../entities/product.entity";
import {
  remove,
  update,
  create,
  findOne,
  find
} from "../repositories/products.repository";

export const findProducts = (): ProductEntity[] => {
  return find();
}

export const findProduct = (id: string): ProductEntity | null => {
  return findOne(id);
}

export const updateProduct = (id: string, data: Omit<ProductEntity, 'id'> ): ProductEntity | null => {
  const updatedProduct = update(
    {
      id,
      ...data
    }
  )
  return updatedProduct;
}

export const createProduct = (data: Omit<ProductEntity, 'id'>): ProductEntity => {
  return create(data);
}

export const removeProduct = (id: string): boolean => {
  const removedRes = remove(id);
  return Boolean(removedRes)
}

