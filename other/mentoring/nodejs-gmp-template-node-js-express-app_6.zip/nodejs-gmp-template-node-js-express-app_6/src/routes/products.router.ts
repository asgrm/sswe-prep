import express from 'express';
import { createNewProduct, getProducts, getProduct, replaceProduct, deleteProduct } from '../controllers/products.controller';
import { joiValidator } from '../middlewares/joi-validator';
import { productSchema } from '../validators/products';

const router = express.Router();

router.post('/', joiValidator(productSchema), createNewProduct);
router.get('/', getProducts);
router.get('/:id', getProduct);
router.put('/:id', joiValidator(productSchema), replaceProduct);
router.delete('/:id', deleteProduct);

export default router;