import express from 'express';
import  productRouter from './products.router'

const rootRouter = express.Router();

rootRouter.use('/api/products', productRouter);

export default rootRouter;