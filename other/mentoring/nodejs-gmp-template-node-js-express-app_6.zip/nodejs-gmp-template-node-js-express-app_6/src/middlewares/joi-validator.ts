import { Request, Response, NextFunction } from 'express';
import Joi, { ObjectSchema, ValidationError } from 'joi';

export function joiValidator(schema: ObjectSchema, property: 'body' | 'query' | 'params' = 'body') {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req[property], { abortEarly: false });

    if (error) {
      res.status(400).json({
        success: false,
        errors: error.details.map((detail) => ({
          message: detail.message,
          field: detail.context?.key,
        })),
      });
      return;
    }
    next();
  };
}