import express from 'express';
import {
  createNewProduct,
  getProducts,
  getProduct,
  replaceProduct,
  deleteProduct

} from '../controllers/products.controller';
import { joiValidator } from '../middlewares/joi-validator';
import { productIdSchema, productSchema } from '../validators/products';

const router = express.Router();

const idValidator = joiValidator(productIdSchema, { property: 'params', key: 'id' });
const bodyValidator = joiValidator(productSchema);

router.post('/', bodyValidator, createNewProduct);
router.get('/', getProducts);
router.get('/:id', idValidator, getProduct);
router.put('/:id', idValidator, bodyValidator, replaceProduct);
router.delete('/:id', idValidator, deleteProduct);

export default router;