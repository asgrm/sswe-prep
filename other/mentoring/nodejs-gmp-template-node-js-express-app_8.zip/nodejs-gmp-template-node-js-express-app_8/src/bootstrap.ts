import express from 'express';
import bodyParser from 'body-parser';
import { Socket } from 'net';
import { Server } from 'http';
import { requestLogger } from './middlewares/request-logger';
import rootRouter from './routes';
import { errorController } from './controllers/error.controller';
import { MikroORM, RequestContext } from '@mikro-orm/core';
import ORMConfig from '../mikro-orm.config'
// import { DB_CONNECTION_STRING } from './env/mongodb-connection';
// import mongoose from 'mongoose';

export const app = express();

app.use(bodyParser.json());
app.use(requestLogger);


/**
 * TODO: Module 10 - Production-Ready Node.js Applications
 * Gracefully shuts down the server by closing all active connections and the server itself.
 * @param {Server} server - The HTTP server instance.
 * @param {Socket[]} connections - List of active connections to be closed.
 * @param {string} signal - The signal received that initiated the shutdown.
 */
export const shutdown = (server: Server, connections: Socket[], signal: string) => {};

const PORT = 8000;


export const bootstrap = async () => {
  try {
    // await mongoose.connect(DB_CONNECTION_STRING);
    const orm = await MikroORM.init(ORMConfig);
    console.log('connected to DB');


    app.use((req, res, next) => {
      RequestContext.create(orm.em, next); // Bind EntityManager to request
    });

    app.use(rootRouter);
    app.use(errorController);

  } catch (error) {
    console.log('Failed to connect to DB');
    console.log(error);
  }
  const server = app.listen(PORT, () => {
    console.log(`Server is started on port ${PORT}`);
  });

  // TODO: Module 10 - Production-Ready Node.js Applications
  // Track new connections to the server
  // const connections: Socket[] = [];

  // Handle termination signals.
  // process.on('SIGTERM', () => shutdown(server, connections, 'SIGTERM'));
  // process.on('SIGINT', () => shutdown(server, connections, 'SIGINT'));

  return server;
};
