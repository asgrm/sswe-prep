import { ProductEntity } from '../entities/product.entity';
import { RequestContext } from '@mikro-orm/core';
import { Product } from '../entities/product.entity';
import { ProductRepository } from '../repositories/products.repository';

class ProductService {
  private getProductRepository(): ProductRepository {
    const em = RequestContext.getEntityManager();
    if (!em) {
      throw new Error('EntityManager not initialized.');
    }
    return em.getRepository(Product) as ProductRepository;
  }

  async findProducts(): Promise<ProductEntity[]> {
    const productRepository = this.getProductRepository();
    return await productRepository.findAllProducts();
  }

  async findProduct(id: string): Promise<ProductEntity | null> {
    const productRepository = this.getProductRepository();
    return await productRepository.findProductById(id);
  }

  async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
    const productRepository = this.getProductRepository();
    return await productRepository.createProduct(data);
  }

  async updateProduct(
    id: string,
    data: Omit<ProductEntity, 'id'>
  ): Promise<ProductEntity | null> {
    const productRepository = this.getProductRepository();
    return await productRepository.updateProduct({
      id,
      ...data,
    });
  }

  async removeProduct(id: string): Promise<boolean> {
    const productRepository = this.getProductRepository();
    return Boolean(await productRepository.removeProductById(id));
  }
}

const productService = new ProductService();

export default productService;
