import  { Request, Response, NextFunction } from 'express';

export const errorController = ((err: Error, req: Request , res: Response, _: NextFunction) => {
  res.status(500).send({ message: err.message });
});