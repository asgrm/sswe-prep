import Joi from "joi";

export const productSchema = Joi.object({
  title: Joi.string().required(),
  description: Joi.string().required(),
  price: Joi.number().required()
});

export const productIdSchema = Joi.object({
  id: Joi.string().uuid().required()
})

