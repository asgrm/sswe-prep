import Joi from "joi";

import { UserRole } from "../entities/user.entity";

export const userRegistrationSchema = Joi.object({
  email: Joi.string().email({ tlds: { allow: false } }).required(),
  password: Joi.string().required(),
  role: Joi.number().valid(...Object.values(UserRole)).required()
});

export const userLoginSchema = Joi.object({
  email: Joi.string().email({ tlds: { allow: false } }).required(),
  password: Joi.string().required(),
});