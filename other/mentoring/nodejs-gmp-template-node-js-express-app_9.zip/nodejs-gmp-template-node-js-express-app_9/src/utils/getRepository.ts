import { EntityRepository, EntityName, RequestContext } from '@mikro-orm/core';


export function getRepository<T extends object, R extends EntityRepository<T>>(entityClass: EntityName<T>): R {
  const em = RequestContext.getEntityManager();

  if (!em) {
    throw new Error('EntityManager not initialized.');
  }

  return em.getRepository(entityClass) as R;
}