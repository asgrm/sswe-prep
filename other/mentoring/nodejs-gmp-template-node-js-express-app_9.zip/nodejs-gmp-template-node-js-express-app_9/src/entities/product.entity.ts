import { Entity, PrimaryKey, Property, EntityRepositoryType  } from '@mikro-orm/core';
import { ProductRepository } from '../repositories/products.repository';

export interface ProductEntity {
  id: string; // uuid
  title: string;
  description: string;
  price: number;
}

// const product: ProductEntity = {
//   id: '51422fcd-0366-4186-ad5b-c23059b6f64f',
//   title: 'Book',
//   description: 'A very interesting book',
//   price: 100,
// };

@Entity({  tableName: 'products', repository: () => ProductRepository })
export class Product implements ProductEntity {
  [EntityRepositoryType]?: ProductRepository;

  @PrimaryKey({ type: 'uuid', defaultRaw: 'uuid_generate_v4()' })
  id!: string;

  @Property({ type: 'string' })
  title!: string;

  @Property({ type: 'text' })
  description!: string;

  @Property({ type: 'decimal', precision: 10, scale: 2 })
  price!: number;

  constructor(id: string, title: string, description: string, price: number) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.price = price;
  }
}