import { EntityRepository, EntityName, RequestContext } from '@mikro-orm/core';

export abstract class AbstractService<T extends object> {
  private entityClass: EntityName<T>;

  constructor(entityClass: EntityName<T>) {
    this.entityClass = entityClass;
  }

  protected getRepository<R extends EntityRepository<T>>(): R {
    const em = RequestContext.getEntityManager();
    if (!em) {
      throw new Error('EntityManager not initialized.');
    }

    return em.getRepository(this.entityClass) as R;
  }
}