import { ProductEntity } from '../entities/product.entity';
import { Product } from '../entities/product.entity';
import { ProductRepository } from '../repositories/products.repository';

import { AbstractService } from './abstract.service';

class ProductService extends AbstractService<Product> {
  constructor() {
    super(Product);
  }

  async findProducts(): Promise<ProductEntity[]> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.findAllProducts();
  }

  async findProduct(id: string): Promise<ProductEntity | null> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.findProductById(id);
  }

  async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.createProduct(data);
  }

  async updateProduct(
    id: string,
    data: Omit<ProductEntity, 'id'>
  ): Promise<ProductEntity | null> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.updateProduct({
      id,
      ...data,
    });
  }

  async removeProduct(id: string): Promise<boolean> {
    const productRepository = this.getRepository<ProductRepository>();
    return Boolean(await productRepository.removeProductById(id));
  }
}

const productService = new ProductService();
export default productService;

// class ProductService {
//   private getRepository(): ProductRepository {
//     const em = RequestContext.getEntityManager();
//     if (!em) {
//       throw new Error('EntityManager not initialized.');
//     }
//     return em.getRepository(Product) as ProductRepository;
//   }

//   async findProducts(): Promise<ProductEntity[]> {
//     const productRepository = this.getRepository();
//     return await productRepository.findAllProducts();
//   }

//   async findProduct(id: string): Promise<ProductEntity | null> {
//     const productRepository = this.getRepository();
//     return await productRepository.findProductById(id);
//   }

//   async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
//     const productRepository = this.getRepository();
//     return await productRepository.createProduct(data);
//   }

//   async updateProduct(
//     id: string,
//     data: Omit<ProductEntity, 'id'>
//   ): Promise<ProductEntity | null> {
//     const productRepository = this.getRepository();
//     return await productRepository.updateProduct({
//       id,
//       ...data,
//     });
//   }

//   async removeProduct(id: string): Promise<boolean> {
//     const productRepository = this.getRepository();
//     return Boolean(await productRepository.removeProductById(id));
//   }
// }

// const productService = new ProductService();

// export default productService;

// import { Product } from './ProductEntity'; // Product entity definition
// import { ProductRepository } from './ProductRepository'; // Product repository implementation