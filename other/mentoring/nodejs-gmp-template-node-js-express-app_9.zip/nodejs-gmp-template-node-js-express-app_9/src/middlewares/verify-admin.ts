import { Request, Response, NextFunction } from 'express';
import { UserRole } from '../entities/user.entity';

// it's supposed to be called only after verifyToken middleware
export function verifyAdmin (req: Request, res: Response, next: NextFunction) {
  if (req?.user?.role !== UserRole.ADMIN) {
    return res.status(403).json({ error: "Admin role is required" });
  }

  next();
}