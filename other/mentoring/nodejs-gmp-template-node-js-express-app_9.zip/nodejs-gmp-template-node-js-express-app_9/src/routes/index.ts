import express from 'express';
import productRouter from './products.router';
import authRouter from './auth.router';
import { notFoundController } from '../controllers/notFound.controller';
import { verifyToken } from '../middlewares/verify-token';

const rootRouter = express.Router();

rootRouter.use('/api/products', verifyToken,  productRouter);
rootRouter.use('/api/auth',  authRouter);
rootRouter.use('*',  notFoundController);

export default rootRouter;