import { defineConfig } from '@mikro-orm/postgresql';
import { PostgreSqlDriver } from '@mikro-orm/postgresql'; // Import PostgreSQL driver
import { Product } from './src/entities/product.entity';
import { User } from './src/entities/user.entity';
import { config } from './src/config'


const {
  DB_NAME,
  DB_USER,
  DB_PASSWORD,
  DB_HOST,
  DB_PORT,
} = config;

export default defineConfig({
  driver: PostgreSqlDriver,
  dbName: DB_NAME,
  user: DB_USER,
  password: DB_PASSWORD,
  host: DB_HOST,
  port: Number(DB_PORT),
  entities: [Product, User], // Path to your entity classes

  migrations: {
    path: './migrations', // Directory where migration files are stored
    glob: '!(*.d).{js,ts}', // Match JS or TS files excluding type definitions
  },
  seeder: {
    path: './seeders', // Directory where seeder files are stored
    defaultSeeder: 'DatabaseSeeder', // Default seeder to run
    glob: '!(*.d).{js,ts}', // Match JS or TS files excluding type definitions
  },
});