import winston from 'winston';
import { config } from '../config';
/**
 * TODO: Module 10 - Production-Ready Node.js Applications
 * Creates a logger instance with configurations specified in the application's config file.
 * Logs are outputted to the console.
 */


const logger = winston.createLogger({
  level: config.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.colorize(),
    winston.format.prettyPrint(),
    winston.format.printf(({ level, message, timestamp }) => {
      return `[${timestamp}] ${level}: ${message}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
  ],
});

export default logger;
