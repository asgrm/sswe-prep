import express from 'express';
import bodyParser from 'body-parser';
import { Socket } from 'net';
import { Server } from 'http';
import { requestLogger } from './middlewares/request-logger';
import rootRouter from './routes';
import { errorController } from './controllers/error.controller';
import { MikroORM, RequestContext } from '@mikro-orm/core';
import ORMConfig from '../mikro-orm.config'
import { UserEntity } from './entities/user.entity';
import path from 'node:path';
import dotenv from 'dotenv';

import { config }from './config'


const env = config.NODE_ENV;
dotenv.config({
  path: path.resolve(process.cwd(), `.env.${env}`)
});

declare global {
  namespace Express {
      interface Request {
          user: Omit<UserEntity, 'password' >
      }
  }
}

export const app = express();

app.use(bodyParser.json());
app.use(requestLogger);


/**
 * TODO: Module 10 - Production-Ready Node.js Applications
 * Gracefully shuts down the server by closing all active connections and the server itself.
 * @param {Server} server - The HTTP server instance.
 * @param {Socket[]} connections - List of active connections to be closed.
 * @param {string} signal - The signal received that initiated the shutdown.
 */

export const shutdown = (server: Server, connections: Socket[], signal: string) => {
  console.log(`Received ${signal}. Initiating graceful shutdown...`);

  connections.forEach((connection) => {
    connection.end();
    setTimeout(() => {
      connection.destroy();
    }, 10000);
  });

  server.close((err) => {
    if (err) {
      console.error("Error shutting down the server:", err);
      process.exit(1);
    } else {
      console.log("Server has been shut down gracefully.");
      process.exit(0);
    }
  });

  setTimeout(() => {
    console.warn("Shutdown process timed out. Forcing exit...");
    process.exit(1);
  }, 20000);
};
const PORT = 8000;

export const bootstrap = async () => {
  try {
    const orm = await MikroORM.init(ORMConfig);
    console.log('connected to DB');


    app.use((req, res, next) => {
      RequestContext.create(orm.em, next); // Bind EntityManager to request
    });

    app.use(rootRouter);
    app.use(errorController);

  } catch (error) {
    console.log('Failed to connect to DB');
    console.log(error);
  }
  const server = app.listen(PORT, () => {
    console.log(`Server is started on port ${PORT}`);
  });

  const connections: Socket[] = [];
  server.on("connection", (connection: Socket) => {
    connections.push(connection);
    connection.on("close", () => {
      connections.splice(connections.indexOf(connection), 1); // Remove connection on close
    });
  });

  // Handle termination signals.
  process.on('SIGTERM', () => shutdown(server, connections, 'SIGTERM'));
  process.on('SIGINT', () => shutdown(server, connections, 'SIGINT'));

  return server;
};

