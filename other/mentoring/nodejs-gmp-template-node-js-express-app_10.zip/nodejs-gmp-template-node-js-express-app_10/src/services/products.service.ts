import { ProductEntity } from '../entities/product.entity';
import { Product } from '../entities/product.entity';
import { ProductRepository } from '../repositories/products.repository';

import { AbstractService } from './abstract.service';

class ProductService extends AbstractService<Product> {
  constructor() {
    super(Product);
  }

  async findProducts(): Promise<ProductEntity[]> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.findAllProducts();
  }

  async findProduct(id: string): Promise<ProductEntity | null> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.findProductById(id);
  }

  async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.createProduct(data);
  }

  async updateProduct(
    id: string,
    data: Omit<ProductEntity, 'id'>
  ): Promise<ProductEntity | null> {
    const productRepository = this.getRepository<ProductRepository>();
    return await productRepository.updateProduct({
      id,
      ...data,
    });
  }

  async removeProduct(id: string): Promise<boolean> {
    const productRepository = this.getRepository<ProductRepository>();
    return Boolean(await productRepository.removeProductById(id));
  }
}

const productService = new ProductService();
export default productService;