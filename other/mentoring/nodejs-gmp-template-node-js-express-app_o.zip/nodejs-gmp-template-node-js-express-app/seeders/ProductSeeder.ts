import { Seeder } from '@mikro-orm/seeder';
import { EntityManager } from '@mikro-orm/core';
import { products } from '../src/data/products';
import { Product } from '../src/entities/product.entity';

export class ProductSeeder extends Seeder {
  async run(em: EntityManager): Promise<void> {
    const existingProductIds = await em.find(Product, {}, { fields: ['id'] });
    const existingIds = new Set(existingProductIds.map((product) => product.id));

    const newProducts = products.filter((productData) => !existingIds.has(productData.id));

    if (newProducts.length === 0) {
      console.log('All products already exist in the database. No new products to insert.');
      return;
    }

    const productEntities = newProducts.map((product) => em.create(Product, product));
    await em.persistAndFlush(productEntities);

    console.log(`${newProducts.length} new products inserted.`);
  }
}
