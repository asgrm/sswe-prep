import { Seeder } from '@mikro-orm/seeder';
import { EntityManager } from '@mikro-orm/core';
import { users } from '../src/data/users';
import { User } from '../src/entities/user.entity';

export class UserSeeder extends Seeder {
  async run(em: EntityManager): Promise<void> {
    const existingUserIds = await em.find(User, {}, { fields: ['id'] });
    const existingIds = new Set(existingUserIds.map((user) => user.id));

    const newUsers = users.filter((userData) => !existingIds.has(userData.id));

    if (newUsers.length === 0) {
      console.log('All users already exist in the database. No new users to insert.');
      return;
    }

    const userEntities = newUsers.map((user) => em.create(User, user));
    await em.persistAndFlush(userEntities);

    console.log(`${newUsers.length} new users inserted.`);
  }
}
