import { NextFunction, Response, Request } from 'express';
import AuthService from '../services/auth.service';

export const register = async (req: Request, res: Response, _: NextFunction) => {
  const { email, password, role } = req.body;

  if (!email || !password || !role) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Email is invalid' });
  }

  const user = await AuthService.register({ email, password, role });
  if (!user) {
    return res.status(409).json({ error: 'User with such email already exists' });
  }

  return res.status(201).json({ data: user, error: null });
};

export const login = async (req: Request, res: Response, _: NextFunction) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Missing email or password' });
  }

  const token = await AuthService.login({ email, password });
  if (!token) {
    return res.status(401).json({ error: 'No such user or password is incorrect' });
  }

  return res.status(200).json({ data: { token }, error: null });
};
