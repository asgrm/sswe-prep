import { Request, Response, NextFunction } from 'express';
import { RequestContext } from '@mikro-orm/core';

export const healthCheckController = async (req: Request, res: Response, _: NextFunction) => {
  try {
    const em = RequestContext.getEntityManager();
    if (!em) {
      throw new Error('EntityManager not initialized.');
    }

    const connection = em.getConnection();
    await connection.execute('SELECT 1'); // DB check

    res.status(200).json({
      status: 'OK',
      uptime: process.uptime(),
    });
  } catch (err: any) {
    res.status(500).json({
      status: 'ERROR',
      message: err.message || 'Internal Server Error',
    });
  }
};
