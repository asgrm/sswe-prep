import { Request, Response, NextFunction } from 'express';

import tokenService from '../services/token.service';
import { getRepository } from '../utils/getRepository';
import { UserRepository } from '../repositories/user.repository';
import { UserEntity, User } from '../entities/user.entity';

export async function verifyToken (req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
      return res.status(401).json({ error: "Token is required" });
  }

  const [tokenType, token] = authHeader.split(' ');

  if (tokenType !== 'Bearer') {
      return res.status(403).json({ error: "Invalid Token" });
  }

  try {
    const decodedUser = tokenService.verify(token);
    if (!decodedUser) {
      return res.status(403 ).json({ error: "Invalid Token" });
  }
    const userRepo = getRepository<UserEntity, UserRepository>(User);
    const user = await userRepo.findUserById(decodedUser.id);
    if (!user) {
        return res.status(404).json({ error: "No such a user" });
    }
    req.user = user;

  } catch (err) {
    return next(err);
  }
  return next();
}