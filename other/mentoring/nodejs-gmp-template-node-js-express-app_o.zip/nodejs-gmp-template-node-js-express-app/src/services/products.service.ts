import { RequestContext } from '@mikro-orm/core';
import { ProductEntity, Product } from '../entities/product.entity';

import { ProductRepository } from '../repositories/products.repository';

class ProductService {
  // eslint-disable-next-line class-methods-use-this
  private getProductRepository(): ProductRepository {
    const em = RequestContext.getEntityManager();
    if (!em) {
      throw new Error('EntityManager not initialized.');
    }
    return em.getRepository(Product) as ProductRepository;
  }

  async findProducts(): Promise<ProductEntity[]> {
    const productRepository = this.getProductRepository();
    return productRepository.findAllProducts();
  }

  async findProduct(id: string): Promise<ProductEntity | null> {
    const productRepository = this.getProductRepository();
    return productRepository.findProductById(id);
  }

  async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
    const productRepository = this.getProductRepository();
    return productRepository.createProduct(data);
  }

  async updateProduct(
    id: string,
    data: Omit<ProductEntity, 'id'>,
  ): Promise<ProductEntity | null> {
    const productRepository = this.getProductRepository();
    return productRepository.updateProduct({
      id,
      ...data,
    });
  }

  async removeProduct(id: string): Promise<boolean> {
    const productRepository = this.getProductRepository();
    return Boolean(await productRepository.removeProductById(id));
  }
}

const productService = new ProductService();

export default productService;
