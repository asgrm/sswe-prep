import jwt from 'jsonwebtoken';
import { JWT_KEY } from '../env/jwt';
import { UserEntity } from '../entities/user.entity';

class TokenService {
  sign(user: Omit<UserEntity, 'password'>, expiresIn = '2h') {
    const { id, email, role } = user;
    const token = jwt.sign({ id, email, role}, JWT_KEY, { expiresIn });
    return token;
  }

  verify(token: string) {
    try {
      const user = jwt.verify(token, JWT_KEY) as Omit<UserEntity, 'password'>;
      return user;
    } catch {
      return null;
    }
  }
}

const tokenService = new TokenService();
export default tokenService;
