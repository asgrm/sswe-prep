import { EntityRepository } from '@mikro-orm/postgresql';
import { randomUUID } from 'crypto';
import { ProductEntity, Product } from '../entities/product.entity';

export class ProductRepository extends EntityRepository<Product> {
  private mapToProductEntity(product: Product): ProductEntity {
    return {
      id: product.id,
      title: product.title,
      description: product.description,
      price: product.price,
    };
  }

  async findAllProducts(): Promise<ProductEntity[]> {
    const products = await this.find({});
    return products.map(this.mapToProductEntity);
  }

  async findProductById(id: string): Promise<ProductEntity | null> {
    const product = await this.findOne({ id });
    return product ? this.mapToProductEntity(product) : null;
  }

  async createProduct(data: Omit<ProductEntity, 'id'>): Promise<ProductEntity> {
    const newProduct = new Product(randomUUID(), data.title, data.description, data.price);

    await this.em.persistAndFlush(newProduct);

    return this.mapToProductEntity(newProduct);
  }

  async updateProduct(data: ProductEntity): Promise<ProductEntity | null> {
    const product = await this.findOne({ id: data.id });
    if (!product) {
      return null;
    }

    product.title = data.title;
    product.description = data.description;
    product.price = data.price;

    await this.em.flush();

    return this.mapToProductEntity(product);
  }

  async removeProductById(id: string): Promise<string | null> {
    const product = await this.findOne({ id });
    if (!product) {
      return null;
    }

    await this.em.removeAndFlush(product);

    return id;
  }
}
