import { Migration } from '@mikro-orm/migrations';

export class Migration20250429102036 extends Migration {
  override async up(): Promise<void> {
    this.addSql('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";');
    this.addSql('create table if not exists "products" ("id" uuid not null default uuid_generate_v4(), "title" varchar(255) not null, "description" text not null, "price" numeric(10,2) not null, constraint "product_pkey" primary key ("id"));');
  }

  override async down(): Promise<void> {
    this.addSql('DROP EXTENSION IF EXISTS "uuid-ossp";');
    this.addSql('drop table if exists "products" cascade;');
  }
}
