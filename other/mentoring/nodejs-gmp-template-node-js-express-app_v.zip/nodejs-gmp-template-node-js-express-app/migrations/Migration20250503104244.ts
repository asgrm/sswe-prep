import { Migration } from '@mikro-orm/migrations';

export class Migration20250503104244 extends Migration {

  override async up(): Promise<void> {
    this.addSql(`create table "users" ("id" uuid not null default uuid_generate_v4(), "email" text not null, "password" text not null, "role" text check ("role" in ('admin', 'user')) not null, constraint "users_pkey" primary key ("id"));`);
  }

  override async down(): Promise<void> {
    this.addSql(`drop table if exists "users" cascade;`);
  }

}
