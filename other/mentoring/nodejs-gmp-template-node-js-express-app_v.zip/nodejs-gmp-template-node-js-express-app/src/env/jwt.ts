export const JWT_KEY = 'SECRET_KEY';
