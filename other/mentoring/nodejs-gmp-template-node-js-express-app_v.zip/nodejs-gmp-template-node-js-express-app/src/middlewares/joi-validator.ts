import { Request, Response, NextFunction } from 'express';
import Joi, { ObjectSchema } from 'joi';

export function joiValidator(
  schema: ObjectSchema | Joi.Schema,
  options: { property?: 'body' | 'query' | 'params'; key?: string } = { property: 'body' },
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const property = options.property || 'body';
    const { key } = options;
    const target = key ? { [key]: req[property][key] } : req[property];

    const { error } = schema.validate(target, { abortEarly: false });

    if (error) {
      res.status(400).json({
        // success: false,
        error: error.details.map((detail) => detail.message).join('; '),
      });
      return;
    }
    next();
  };
}
