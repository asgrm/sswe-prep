import { EntityRepository, EntityName, RequestContext } from '@mikro-orm/core';

// eslint-disable-next-line max-len
export function getRepository<T extends object, R extends EntityRepository<T>>(entityClass: EntityName<T>): R {
  const em = RequestContext.getEntityManager();

  if (!em) {
    throw new Error('EntityManager not initialized.');
  }

  return em.getRepository(entityClass) as R;
}
