import bcrypt from 'bcrypt';
import { UserEntity, User } from '../entities/user.entity';

import { UserRepository } from '../repositories/user.repository';
import { AbstractService } from './abstract.service';
import tokenService from './token.service';

class AuthService extends AbstractService<User> {
  constructor() {
    super(User);
  }

  async register(data: Omit<UserEntity, 'id'>): Promise<Omit<User, 'password'> | null> {
    const userRepository = this.getRepository<UserRepository>();
    console.log('AuthService register');
    const existingUser = await userRepository.findUserByEmail(data.email);
    if (existingUser) {
      return null;
    }

    const encryptedPass = await bcrypt.hash(data.password, 10);
    // eslint-disable-next-line no-param-reassign
    data.password = encryptedPass;

    const createdUser = await userRepository.createUser(data);
    return createdUser;
  }

  async login(data: Pick<UserEntity, 'email' | 'password'>): Promise<string | null> {
    const userRepository = this.getRepository<UserRepository>();
    const user = await userRepository.findUserByEmail(data.email);
    if (user === null) {
      return null;
    }

    const isMatch = await bcrypt.compare(data.password, user.password);
    if (!isMatch) {
      return null;
    }
    return tokenService.sign(user);
  }
}

const authService = new AuthService();

export default authService;
