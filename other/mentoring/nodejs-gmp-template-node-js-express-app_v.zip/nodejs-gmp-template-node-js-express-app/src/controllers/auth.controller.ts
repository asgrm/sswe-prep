import { NextFunction, Response, Request } from 'express';
import AuthService from '../services/auth.service';

export const register = async (req: Request, res:Response, _: NextFunction) => {
  const { body: data } = req;

  const user = await AuthService.register(data);
  if (!user) {
    return res.status(409).json({
      error: 'User with such email already exists',
    });
  }
  return res.status(201).json({
    data: user,
    error: null,
  });
};

export const login = async (req: Request, res:Response, _: NextFunction) => {
  const { body: data } = req;

  const token = await AuthService.login(data);
  if (!token) {
    return res.status(401).json({
      error: 'No such user or password provided is not correct',
    });
  }
  return res.status(200).json({
    data: { token },
    error: null,
  });
};
