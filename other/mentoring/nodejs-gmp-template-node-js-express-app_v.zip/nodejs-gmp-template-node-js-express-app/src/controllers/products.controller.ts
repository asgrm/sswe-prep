import { NextFunction, Response, Request } from 'express';
import ProductService from '../services/products.service';

export const getProducts = async (req: Request, res:Response, _: NextFunction) => {
  const products = await ProductService.findProducts();
  res.status(200).json({
    data: products,
  });
};

export const getProduct = async (req: Request, res:Response, _: NextFunction) => {
  const { id } = req.params;

  const product = await ProductService.findProduct(id);

  if (!product) {
    return res.status(404).json({
      error: 'Product not found',
    });
  }

  return res.status(200).json({
    data: product,
  });
};

export const createNewProduct = async (req: Request, res:Response, _: NextFunction) => {
  const { body: data } = req;

  const newProduct = await ProductService.createProduct(data);
  return res.status(201).json({
    data: newProduct,
  });
};

export const replaceProduct = async (req: Request, res:Response, _: NextFunction) => {
  const { body: data } = req;
  const { id } = req.params;

  const updatedProduct = await ProductService.updateProduct(id, data);
  if (!updatedProduct) {
    return res.status(404).json({
      error: 'Product not found',
    });
  }
  return res.status(200).json({
    data: updatedProduct,
  });
};

export const deleteProduct = async (req: Request, res:Response, _: NextFunction) => {
  const { id } = req.params;

  const removed = await ProductService.removeProduct(id);

  if (!removed) {
    return res.status(404).json({
      error: 'Product not found',
    });
  }
  return res.status(200).json({ message: 'Product deleted successfully' });
};
