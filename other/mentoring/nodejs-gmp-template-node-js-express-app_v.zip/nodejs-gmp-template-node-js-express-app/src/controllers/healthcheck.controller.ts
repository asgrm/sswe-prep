import { MikroORM, RequestContext } from '@mikro-orm/core';
import { Request, Response, NextFunction } from 'express';

export const healthCheckController = async (req: Request, res: Response, _: NextFunction) => {
  try {
    const em = RequestContext.getEntityManager();
    if (!em) {
      throw new Error('EntityManager not initialized.');
    }
    const connection = em.getConnection();

    await connection.execute('SELECT 1');

    res.status(200).json({ status: 'OK', uptime: process.uptime() });
  } catch (err: any) {
    res.status(500).json({ status: 'ERROR', message: err.message });
  }
};
