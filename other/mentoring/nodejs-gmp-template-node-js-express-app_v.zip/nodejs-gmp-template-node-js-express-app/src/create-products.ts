import mongoose from 'mongoose';

import { DB_CONNECTION_STRING } from './env/mongodb-connection';
import { products } from './data/products';
import { Product } from './models/product';

const populateDatabase = async () => {
  try {
    // Connect to MongoDB

    await mongoose.connect(DB_CONNECTION_STRING);

    console.log('Connected to MongoDB before pre-population');

    // Clear the Product collection (remove all existing documents)
    await Product.deleteMany({});
    console.log('Cleared Product collection');

    // Insert new product data
    await Product.insertMany(products);
    console.log('Products reinserted into the database');
  } catch (error) {
    console.error('Error during MongoDB pre-population:', error);
  } finally {
    // Close the connection to MongoDB
    await mongoose.connection.close();
    console.log('Closed MongoDB connection');
  }
};

// Invoke the function to populate the database
populateDatabase();
