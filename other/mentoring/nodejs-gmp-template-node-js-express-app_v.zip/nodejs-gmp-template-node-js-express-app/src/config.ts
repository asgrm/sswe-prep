import dotenv from 'dotenv';
import path from 'node:path';

const env = process.env.NODE_ENV || 'test';

dotenv.config({
  path: path.resolve(process.cwd(), `.env.${env}`),
});

/**
 * TODO: Module 10 - Production-Ready Node.js Applications
 * Configuration object containing the necessary environment variables for the application.
 * Provides defaults for each variable if not specified in the environment.
 */

export const config = {
  PORT: process.env.PORT || '8000',
  NODE_ENV: process.env.NODE_ENV || 'test',
  LOG_LEVEL: process.env.LOG_LEVEL || 'debug',
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD,
  DB_NAME: process.env.DB_NAME,
  DB_HOST: process.env.DB_HOST,
  DB_PORT: process.env.DB_PORT,

};
/**
 * TODO: Module 10 - Production-Ready Node.js Applications
 * Validates the presence of required environment variables.
 * @throws {Error} If a required environment variable is missing.
 */
export const validateEnv = () => {
  const requiredVariables = ['PORT', 'NODE_ENV', 'LOG_LEVEL'];

  const missingVariables = requiredVariables.filter(
    (variable) => !process.env[variable],
  );

  if (missingVariables.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missingVariables.join(', ')}`,
    );
  }
};
