import { EntityRepository } from '@mikro-orm/postgresql';
import { randomUUID } from 'crypto';
import { User, UserEntity } from '../entities/user.entity';

export class UserRepository extends EntityRepository<User> {
  // eslint-disable-next-line class-methods-use-this
  private mapToUserEntity(user: User): UserEntity {
    return {
      id: user.id,
      email: user.email,
      password: user.password,
      role: user.role,
    };
  }

  // eslint-disable-next-line class-methods-use-this
  private mapToUserEntitySafe(user: User): Omit<UserEntity, 'password'> {
    return {
      id: user.id,
      email: user.email,
      role: user.role,
    };
  }

  async findUserByEmail(email: string): Promise<UserEntity | null> {
    const user = await this.findOne({ email });
    return user ? this.mapToUserEntity(user) : null;
  }

  async findUserById(id: string): Promise<Omit<UserEntity, 'password'> | null> {
    const user = await this.findOne({ id });
    return user ? this.mapToUserEntitySafe(user) : null;
  }

  async createUser(data: Omit<UserEntity, 'id'>): Promise<Omit<UserEntity, 'password'>> {
    const newUser = new User(randomUUID(), data.email, data.password, data.role);

    await this.em.persistAndFlush(newUser);

    return this.mapToUserEntitySafe(newUser);
  }
}
