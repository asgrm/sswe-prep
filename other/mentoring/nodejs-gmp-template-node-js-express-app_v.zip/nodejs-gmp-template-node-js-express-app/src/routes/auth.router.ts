import express from 'express';
import {
  register,
  login,
} from '../controllers/auth.controller';
import { joiValidator } from '../middlewares/joi-validator';

import { userLoginSchema, userRegistrationSchema } from '../validators/users';

const router = express.Router();

router.post('/register', joiValidator(userRegistrationSchema), register);
router.post('/login', joiValidator(userLoginSchema), login);

export default router;
