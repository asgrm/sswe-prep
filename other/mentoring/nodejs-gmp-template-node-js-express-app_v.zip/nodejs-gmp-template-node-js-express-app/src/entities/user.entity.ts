/* eslint-disable no-shadow */
import {
  Entity, PrimaryKey, Property, EntityRepositoryType, Enum,
} from '@mikro-orm/core';
import { UserRepository } from '../repositories/user.repository';

export enum UserRole {
  ADMIN = 'admin',
  USER = 'user',
}

export interface UserEntity {
  id: string; // uuid
  email: string;
  password: string;
  role: UserRole,
}

// const user: UserEntity = {
//   id: '7ed47722-4381-4d60-8619-7cc867e1f7ae',
//   email: 'admin@admin.admin',
//   password: '$2b$10$23Y3t/3ojY5/OMn5YMKtYec6fM1yE0POTNuWS3dmwOnbx.BL.pxgK', // raw value = admin
//   role: UserRole.ADMIN,
// };

@Entity({ tableName: 'users', repository: () => UserRepository })
export class User implements UserEntity {
  [EntityRepositoryType]?: UserRepository;

  @PrimaryKey({ type: 'uuid', defaultRaw: 'uuid_generate_v4()' })
    id!: string;

  @Property({ type: 'text' })
    email!: string;

  @Property({ type: 'text', hidden: true })
    password!: string;

  @Enum(() => UserRole)
    role!: UserRole;

  constructor(id: string, email: string, password: string, role: UserRole) {
    this.id = id;
    this.email = email;
    this.password = password;
    this.role = role;
  }
}
