import { ProductEntity } from "../entities/product.entity";
import { Product } from "../models/product";
import { mapToProductEntity } from "../utils/mapToProductEntity";
import { randomUUID } from "crypto";

export const find = async (): Promise<ProductEntity[]> => {
  const products = await Product.find();
  return products.map(mapToProductEntity);
};

export const findOne = async (id: string): Promise<ProductEntity | null> => {
  const product = await Product.findOne({ id });
  return product ? mapToProductEntity(product) : null;
};

export const create = async (data: Omit<ProductEntity, "id">): Promise<ProductEntity> => {
  const newProduct = new Product({ ...data, id: randomUUID() });
  const savedProduct = await newProduct.save();
  return mapToProductEntity(savedProduct);
};

export const update = async (data: ProductEntity): Promise<ProductEntity | null> => {
  const updatedProduct = await Product.findOneAndUpdate(
    { id: data.id },
    {
      title: data.title,
      description: data.description,
      price: data.price,
    },
    { new: true, runValidators: true }
  );
  return updatedProduct ? mapToProductEntity(updatedProduct) : null;
};

export const remove = async (id: string): Promise<string | null> => {
  const deletedProduct = await Product.findOneAndDelete({ id });
  return deletedProduct ? id : null;
};