import { ProductEntity } from "../entities/product.entity";
import {
  remove,
  update,
  create,
  findOne,
  find,
} from "../repositories/products.repository";

export const findProducts = async (): Promise<ProductEntity[]> => {
  return await find();
};

export const findProduct = async (id: string): Promise<ProductEntity | null> => {
  return await findOne(id);
};

export const updateProduct = async (
  id: string,
  data: Omit<ProductEntity, 'id'>
): Promise<ProductEntity | null> => {
  const updatedProduct = await update({
    id,
    ...data,
  });
  return updatedProduct;
};

export const createProduct = async (
  data: Omit<ProductEntity, 'id'>
): Promise<ProductEntity> => {
  return await create(data);
};

export const removeProduct = async (id: string): Promise<boolean> => {
  const removedRes = await remove(id);
  return Boolean(removedRes);
};
