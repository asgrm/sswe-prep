import { ProductEntity } from "../entities/product.entity";

export const mapToProductEntity = (product: any): ProductEntity => ({
  id: product.id,
  title: product.title,
  description: product.description,
  price: product.price,
});