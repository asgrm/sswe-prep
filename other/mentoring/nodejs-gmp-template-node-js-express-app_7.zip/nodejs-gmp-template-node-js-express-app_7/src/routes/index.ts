import express from 'express';
import  productRouter from './products.router'
import { notFoundController } from '../controllers/notFound.controller';

const rootRouter = express.Router();

rootRouter.use('/api/products',  productRouter);

rootRouter.use('*',  notFoundController);

export default rootRouter;